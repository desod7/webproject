import sqlalchemy
from .db_session import SqlAlchemyBase
from sqlalchemy import orm


class Towns(SqlAlchemyBase):
    __tablename__ = 'towns'

    id_town = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    town_name = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    # Создаем внешний ключ к таблицам Polution и FedOkrug
    id_uzag = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("polution.id_uzag"))
    id_fo = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("fed_okrug.id_fo"))
