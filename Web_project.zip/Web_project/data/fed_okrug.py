import sqlalchemy
from .db_session import SqlAlchemyBase
from sqlalchemy import orm


class FedOkrug(SqlAlchemyBase):
    __tablename__ = 'fed_okrug'

    id_fo = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    fed_okrug_name = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    town = orm.relationship('Towns')
