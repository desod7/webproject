import sqlalchemy
from .db_session import SqlAlchemyBase
from sqlalchemy import orm


class Polution(SqlAlchemyBase):
    __tablename__ = 'polution'

    id_uzag = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    uzag_name = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    town = orm.relationship('Towns')
