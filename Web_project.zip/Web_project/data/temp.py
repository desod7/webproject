import sqlalchemy
from .db_session import SqlAlchemyBase


class Temp(SqlAlchemyBase):
    __tablename__ = 'temp'

    id_temp = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    temp_name = sqlalchemy.Column(sqlalchemy.String, nullable=False)
