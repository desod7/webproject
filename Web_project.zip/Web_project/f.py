import requests


def city_to_map(city):
    geocoder_request = f"http://geocode-maps.yandex.ru/1.x/?apikey=40d1649f-0493-4b70-98ba-98533de7710b&geocode={city}&format=json"


    response = requests.get(geocoder_request)
    json_response = response.json()
    toponym = json_response["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]
    toponym_coodrinates = toponym["Point"]["pos"]
    map1_request = f"https://static-maps.yandex.ru/1.x/?ll={','.join(toponym_coodrinates.split())}&z=12&size=650,300&l=map"
    map2_request = f"https://static-maps.yandex.ru/1.x/?ll={','.join(toponym_coodrinates.split())}&z=12&size=650,300&l=sat"
    response1 = requests.get(map1_request)
    response2 = requests.get(map2_request)
    map1_file = "static/image/map1.png"
    map2_file = "static/image/map2.png"
    with open(map1_file, "wb") as file:
        file.write(response1.content)
    with open(map2_file, "wb") as file:
        file.write(response2.content)
