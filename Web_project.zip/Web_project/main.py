from flask import Flask, render_template, redirect
from flask_wtf import FlaskForm
from wtforms import SubmitField, SelectField
from data import db_session
import city_to_data
from f import city_to_map
from data.polution import Polution
from data.towns import Towns
from data.fed_okrug import FedOkrug
from data.temp import Temp
import csv




def main():
    # Создаем переменную для проверки заполнения базы данных
    is_first_csv = True
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
    db_session.global_init("db/db_towns.db")
    db_sess = db_session.create_session()
    x = 0
    for i in db_sess.query(Towns):
        x += 1
    if x != 0:
        is_first_csv = False

    @app.route('/login')
    def i():
        city_to_map(city)
        db_sess = db_session.create_session()
        for row in db_sess.query(Towns).filter(Towns.town_name == city):
            pol_in = row.id_uzag
        for row in db_sess.query(Polution).filter(Polution.id_uzag == pol_in):
            r = row.uzag_name
        db_sess.commit()
        return render_template('index.html', string1=city_to_data.city_to_data(city), string2=r)

    class Login(FlaskForm):
        db_sess = db_session.create_session()
        fedoks = []
        for fedok in db_sess.query(FedOkrug):
            fedoks.append(fedok.fed_okrug_name)
        db_sess.commit()
        listi = SelectField('Список округов', choices=fedoks)
        submit = SubmitField('Продолжить путь')

    @app.route('/base', methods=['GET', 'POST'])
    def base():
        db_sess = db_session.create_session()
        fedoks = []
        for fedok in db_sess.query(FedOkrug):
            fedoks.append(fedok.fed_okrug_name)
        db_sess.commit()
        form = Login()
        if form.validate_on_submit():
            db_sess = db_session.create_session()
            m = db_sess.query(Temp).first()
            m.temp_name = form.listi.data
            db_sess.commit()
            return redirect('/base2')
        return render_template("login.html", title='Авторизация', form=form)

    @app.route('/base2', methods=['GET', 'POST'])
    def base2():
        class Login2(FlaskForm):
            d = []
            db_sess = db_session.create_session()
            fedokr = db_sess.query(Temp).first().temp_name
            for row in db_sess.query(FedOkrug).filter(FedOkrug.fed_okrug_name == fedokr):
                f = row
            listi = f.town
            for elem in listi:
                d.append(elem.town_name)
            listi = SelectField('Список городов', choices=d)
            submit = SubmitField('Перейти к информации')

        form = Login2()
        if form.validate_on_submit():
            global city
            city = form.listi.data
            return redirect('/login')
        return render_template("login2.html", title='Авторизация', form=form)

    if is_first_csv:
        db_sess = db_session.create_session()
        with open('csv/UZag (1).csv') as csvfile:
            reader = csv.reader(csvfile, delimiter=';')
            for row in reader:
                if row[0] != 'ID_UZag':
                    pol = Polution()
                    pol.uzag_name = row[1]
                    db_sess.add(pol)
        with open('csv/FO (1).csv') as csvfile:
            reader = csv.reader(csvfile, delimiter=';')
            for row in reader:
                if row[0] != 'ID_FO':
                    fo = FedOkrug()
                    fo.fed_okrug_name = row[1]
                    db_sess.add(fo)
        with open('csv/Towns (1).csv') as csvfile:
            reader = csv.reader(csvfile, delimiter=';')
            for row in reader:
                if row[0] != 'Город':
                    town = Towns()
                    town.town_name = row[0]
                    town.id_uzag = row[1]
                    town.id_fo = row[2]
                    db_sess.add(town)
        db_sess.commit()

    app.run()


if __name__ == '__main__':
    main()
