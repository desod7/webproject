import wikipedia


def city_to_data(city):
    language = "ru"
    wikipedia.set_lang(language)
    result = wikipedia.summary(city)
    return result
